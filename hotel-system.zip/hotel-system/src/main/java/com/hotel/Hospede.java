package com.hotel;

import java.util.Objects;

public class Hospede {
    private String nome, cpf, telefone, email, endereco;

    public Hospede(String nome, String cpf, String telefone, String email, String endereco) {
        setNome(nome);
        setCpf(cpf);
        setTelefone(telefone);
        setEmail(email);
        setEndereco(endereco);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Hospede hospede = (Hospede) o;
        return Objects.equals(cpf.replaceAll("\\D", ""), hospede.cpf.replaceAll("\\D", ""));
    }

    @Override
    public int hashCode() {
        return Objects.hash(cpf.replaceAll("\\D", ""));
    }
    
    private String formatarNome(String nome){
        if(nome == null || nome.isBlank()){
            throw new IllegalArgumentException("O nome do hóspede é obrigatório.");
        }

        String[] palavras = nome.trim().toLowerCase().split("\\s+");
        StringBuilder sb = new StringBuilder();

        for (String palavra : palavras) {
            if (!palavra.isEmpty()) {
                sb.append(Character.toUpperCase(palavra.charAt(0))).append(palavra.substring(1)).append(" ");
            }
        }
        return sb.toString().trim();
    }

    private String formatarCpf(String cpf){
        if(cpf == null || cpf.isBlank()){
            throw new IllegalArgumentException("O cpf do hóspede é obrigatório.");
        }
        
        String apenasNumeros = cpf.replaceAll("\\D", "");
        if (apenasNumeros.length() == 11) {
            return apenasNumeros.replaceAll("(\\d{3})(\\d{3})(\\d{3})(\\d{2})", "$1.$2.$3-$4");
        }
        return cpf;
    }

    private String formatarTelefone(String telefone) {
        if (telefone == null || telefone.isBlank()) {
            throw new IllegalArgumentException("O telefone do hóspede é obrigatório.");
        }
        
        String apenasNumeros = telefone.replaceAll("\\D", "");
        if (apenasNumeros.length() == 11) {
            return apenasNumeros.replaceAll("(\\d{2})(\\d{5})(\\d{4})", "($1) $2-$3");
        } else if (apenasNumeros.length() == 10) {
            return apenasNumeros.replaceAll("(\\d{2})(\\d{4})(\\d{4})", "($1) $2-$3");
        }
        return telefone;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = formatarNome(nome);
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = formatarCpf(cpf);
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = formatarTelefone(telefone);
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        if (email == null || email.isBlank()) {
            throw new IllegalArgumentException("O e-mail do hóspede é obrigatório.");
        }
        this.email = email.trim().toLowerCase();
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        if (endereco == null || endereco.isBlank()) {
            throw new IllegalArgumentException("O endereço do hóspede é obrigatório.");
        }
        this.endereco = endereco.trim();
    }

    @Override
    public String toString() {
        return "Hóspede: " + nome + " | CPF: " + cpf + " | Tel: " + telefone + " | Email: " + email + " | Endereço: " + endereco;
    }
}