package com.hotel;

import com.google.gson.Gson;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class ServicoViaCep {

    public static class Endereco {
        private String cep;
        private String logradouro;
        private String bairro;
        private String localidade;
        private String uf;
        private boolean erro;

        public String getLogradouro() { return logradouro; }
        public String getBairro() { return bairro; }
        public String getLocalidade() { return localidade; }
        public String getUf() { return uf; }
        public boolean isErro() { return erro; }

        @Override
        public String toString() {
            return logradouro + ", " + bairro + " - " + localidade + "/" + uf;
        }
    }

    public static Endereco buscarEndereco(String cep) {
        String cepLimpo = cep.replaceAll("[^0-9]", "");
        
        if (cepLimpo.length() != 8) {
            throw new IllegalArgumentException("CEP deve conter 8 dígitos.");
        }

        String url = "https://viacep.com.br/ws/" + cepLimpo + "/json/";

        try {
            HttpClient client = HttpClient.newHttpClient();
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .GET()
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            Gson gson = new Gson();
            Endereco endereco = gson.fromJson(response.body(), Endereco.class);

            if (endereco == null || endereco.isErro()) {
                throw new IllegalArgumentException("CEP não encontrado.");
            }

            return endereco;

        } catch (Exception e) {
            throw new IllegalArgumentException("Erro ao buscar CEP: " + e.getMessage());
        }
    }
}