package com.hotel;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;

public class Hospedagem {
    private String id;
    private Hospede hospede;
    private Quarto quarto;
    private Reserva reserva;
    private double valorTotal;
    private LocalDate dataCheckIN, dataCheckOUT;
    ArrayList<ServicoAdicional> listadeServicos = new ArrayList<>();

    public Hospedagem(String id, Reserva reserva) {
        if (reserva == null) {
            throw new IllegalArgumentException("Reserva inválida.");
        }
        this.id = id;
        this.reserva = reserva;
        this.hospede = reserva.getHospede();
        this.quarto = reserva.getQuarto();
        this.dataCheckIN = reserva.getDataEntradaPrevista();
        this.dataCheckOUT = reserva.getDataSaidaPrevista();
        
        this.quarto.setDisponivel(false);
    }

    public Hospedagem(String id, Hospede hospede, Quarto quarto, LocalDate dataCheckIN, LocalDate dataCheckOUT) {
        if (hospede == null || quarto == null) {
            throw new IllegalArgumentException("Hóspede e Quarto são obrigatórios.");
        }
        if (!quarto.isDisponivel()) {
            throw new IllegalArgumentException("Quarto já está ocupado.");
        }
        this.id = id;
        this.hospede = hospede;
        this.quarto = quarto;
        this.reserva = null; // sem reserva
        this.dataCheckIN = dataCheckIN;
        this.dataCheckOUT = dataCheckOUT;

        this.quarto.setDisponivel(false);
    }

    public void adicionarServico(ServicoAdicional servico){
        listadeServicos.add(servico);
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Hospede getHospede() {
        return hospede;
    }

    public void setHospede(Hospede hospede) {
        this.hospede = hospede;
    }

    public Quarto getQuarto() {
        return quarto;
    }

    public void setQuarto(Quarto quarto) {
        this.quarto = quarto;
    }

    public Reserva getReserva() {
        return reserva;
    }

    public void setReserva(Reserva reserva) {
        this.reserva = reserva;
    }

    public double getValorTotal() {
        if(reserva == null){
            valorTotal = (quarto.getValorDiaria() * (ChronoUnit.DAYS.between(dataCheckIN, dataCheckOUT)));
        for (ServicoAdicional servicoAdicional : listadeServicos) {
            valorTotal += servicoAdicional.getValor();
        }
        }else{
            valorTotal = (reserva.getQuarto().getValorDiaria() * (ChronoUnit.DAYS.between(reserva.getDataEntradaPrevista(), reserva.getDataSaidaPrevista()))) * reserva.calcularDescontoAntecedencia(); 
            for (ServicoAdicional servicoAdicional : listadeServicos) {
                valorTotal += servicoAdicional.getValor();
            }
        }
        return valorTotal;
    }

    public void setValorTotal(double valorTotal) {
        this.valorTotal = valorTotal;
    }

    public LocalDate getDataCheckIN() {
        return dataCheckIN;
    }

    public void setDataCheckIN(LocalDate dataCheckIN) {
        this.dataCheckIN = dataCheckIN;
    }

    public LocalDate getDataCheckOUT() {
        return dataCheckOUT;
    }

    public void setDataCheckOUT(LocalDate dataCheckOUT) {
        this.dataCheckOUT = dataCheckOUT;
    }

    @Override
    public String toString() {
        return "Hospedagem " + id + " | Hóspede: " + hospede.getNome() + 
               " | Quarto: " + quarto.getNumero() + 
               " | Total: R$ " + getValorTotal();
    }
    
}
