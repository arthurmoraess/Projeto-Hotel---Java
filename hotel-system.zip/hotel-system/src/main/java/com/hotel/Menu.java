package com.hotel;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Scanner;

public class Menu {
    private static final DateTimeFormatter FORMATO_DATA = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    
    private Hotel hotel;
    private Scanner scanner;

    public Menu(Hotel hotel) {
        this.hotel = hotel;
        this.scanner = new Scanner(System.in);
    }

    public void iniciar() {
        int opcao = -1;

        while (opcao != 0) {
            System.out.println("\n========== MENU HOTEL: " + hotel.getNome().toUpperCase() + " ==========");
            System.out.println("1. Cadastrar Hóspede");
            System.out.println("2. Cadastrar Quarto");
            System.out.println("3. Cadastrar Serviço Adicional");
            System.out.println("4. Realizar Reserva");
            System.out.println("5. Realizar Hospedagem (Check-in)");
            System.out.println("6. Adicionar Serviço à Hospedagem");
            System.out.println("7. Relatórios / Listar Dados");
            System.out.println("8. Salvar Dados em JSON");
            System.out.println("9. Editar Hospedagem");
            System.out.println("10. Cancelar Reserva");
            System.out.println("11. Realizar Check-out");
            System.out.println("0. Sair");

            opcao = lerInteiroValido("Escolha uma opção: ");
            
            try {
                switch (opcao) {
                    case 1 -> cadastrarHospede();
                    case 2 -> cadastrarQuarto();
                    case 3 -> cadastrarServico();
                    case 4 -> realizarReserva();
                    case 5 -> realizarHospedagem();
                    case 6 -> adicionarServicoHospedagem();
                    case 7 -> listarRelatorios();
                    case 8 -> PersistenciaJson.salvar(hotel);
                    case 9 -> editarHospedagem();
                    case 10 -> cancelarReserva();
                    case 11 -> checkOut();
                    case 0 -> {
                        PersistenciaJson.salvar(hotel);
                        System.out.println("Sistema encerrado.");
                    }
                    default -> System.out.println("Comando inválido! Escolha uma opção do menu.");
                }
            } catch (IllegalArgumentException e) {
                System.out.println("Erro na operação: " + e.getMessage());
            } catch (Exception e) {
                System.out.println("Erro inesperado: " + e.getMessage());
            }
        }
        scanner.close();
    }

    private void cadastrarHospede() {
        System.out.println("\n--- CADASTRO DE HÓSPEDE ---");
        String nome = lerTextoValido("Nome: ");
        String cpf = lerTextoValido("CPF: ");
        String telefone = lerTextoValido("Telefone: ");
        String email = lerTextoValido("E-mail: ");
        
        String endereco = lerEnderecoPorCep();

        Hospede hospede = new Hospede(nome, cpf, telefone, email, endereco);
        hotel.cadastrarHospede(hospede);
        System.out.println("Hóspede cadastrado com sucesso!");
    }

    private void cadastrarQuarto() {
        System.out.println("\n--- CADASTRO DE QUARTO ---");
        String numero = lerTextoValido("Número do quarto: ");

        System.out.println("Valores de Diária Aceitos:");
        System.out.println(" - R$ 125.00 (Essencial)");
        System.out.println(" - R$ 250.00 (Confort)");
        System.out.println(" - R$ 500.00 (Deluxe)");
        
        double valor = lerDoubleValido("Digite o valor da diária: R$ ");

        Quarto quarto = new Quarto(numero, valor, true);
        hotel.cadastrarQuarto(quarto);
        System.out.println("Quarto cadastrado com sucesso!");
    }

    private void cadastrarServico() {
        System.out.println("\n--- CADASTRO DE SERVIÇO ADICIONAL ---");
        String descricao = lerTextoValido("Descrição do serviço: ");
        double valor = lerDoubleValido("Valor do serviço: R$ ");

        ServicoAdicional servico = new ServicoAdicional(descricao, valor);
        hotel.cadastrarServicoAdicional(servico);
        System.out.println("Serviço cadastrado com sucesso!");
    }

    private void realizarReserva() {
        System.out.println("\n--- REALIZAR RESERVA ---");
        if (hotel.getListadeHospedes().isEmpty() || hotel.getListadeQuartos().isEmpty()) {
            System.out.println("É necessário ter pelo menos 1 hóspede e 1 quarto cadastrados.");
            return;
        }

        Hospede hospede = lerHospedeExistente();
        Quarto quarto = lerQuartoExistente();

        LocalDate entrada = lerDataValida("Data Entrada Prevista (dd/MM/yyyy): ");
        LocalDate saida = lerDataValida("Data Saída Prevista (dd/MM/yyyy): ");

        Reserva reserva = new Reserva(hospede, quarto, entrada.format(FORMATO_DATA), saida.format(FORMATO_DATA));
        hotel.cadastrarReserva(reserva);
        System.out.println("Reserva realizada com sucesso!");
    }

    private void realizarHospedagem() {
        System.out.println("\n--- CHECK-IN / HOSPEDAGEM ---");
        System.out.println("1. Hospedagem a partir de Reserva");
        System.out.println("2. Hospedagem Direta (Balcão)");
        
        int tipo = 0;
        while (tipo != 1 && tipo != 2) {
            tipo = lerInteiroValido("Escolha (1 ou 2): ");
            if (tipo != 1 && tipo != 2) {
                System.out.println("Comando inválido! Escolha a opção 1 ou 2.");
            }
        }

        String id = lerTextoValido("ID para esta Hospedagem (ex: H1): ");

        if (tipo == 1) {
            if (hotel.getListadeReservas().isEmpty()) {
                System.out.println("Nenhuma reserva cadastrada.");
                return;
            }
            Reserva reserva = lerReservaExistente();

            Hospedagem hospedagem = new Hospedagem(id, reserva);
            hotel.cadastrarHospedagem(hospedagem);
            System.out.println("Check-in a partir da reserva realizado com sucesso!");

        } else {
            Hospede hospede = lerHospedeExistente();
            Quarto quarto = lerQuartoExistente();

            LocalDate checkIn = lerDataValida("Data Check-in (dd/MM/yyyy): ");
            LocalDate checkOut = lerDataValida("Data Check-out (dd/MM/yyyy): ");

            Hospedagem hospedagem = new Hospedagem(id, hospede, quarto, checkIn, checkOut);
            hotel.cadastrarHospedagem(hospedagem);
            System.out.println("Check-in direto realizado com sucesso!");
        }
    }

    private void adicionarServicoHospedagem() {
        System.out.println("\n--- ADICIONAR SERVIÇO À HOSPEDAGEM ---");
        if (hotel.getListadeHospedagens().isEmpty() || hotel.getListadeServicos().isEmpty()) {
            System.out.println("É necessário ter pelo menos 1 hospedagem e 1 serviço cadastrado.");
            return;
        }

        Hospedagem hospedagem = lerHospedagemExistente();

        System.out.println("Serviços Disponíveis:");
        for (int i = 0; i < hotel.getListadeServicos().size(); i++) {
            System.out.println((i + 1) + ". " + hotel.getListadeServicos().get(i));
        }

        int idx = -1;
        int maxServicos = hotel.getListadeServicos().size();
        while (idx < 0 || idx >= maxServicos) {
            int escolha = lerInteiroValido("Escolha o número do serviço: ");
            idx = escolha - 1;
            if (idx < 0 || idx >= maxServicos) {
                System.out.println("Comando inválido! Escolha um serviço da lista acima.");
            }
        }

        hospedagem.adicionarServico(hotel.getListadeServicos().get(idx));
        System.out.println("Serviço adicionado com sucesso à hospedagem!");
    }

    private void listarRelatorios() {
        System.out.println("\n========== RELATÓRIOS ==========");

        System.out.println("\n[HÓSPEDES]");
        if (hotel.getListadeHospedes() != null && !hotel.getListadeHospedes().isEmpty()) {
            for (Hospede hospede : hotel.getListadeHospedes()) {
                System.out.println(hospede);
            }
        } else {
            System.out.println("Nenhum hóspede cadastrado.");
        }

        System.out.println("\n[QUARTOS]");
        if (hotel.getListadeQuartos() != null && !hotel.getListadeQuartos().isEmpty()) {
            for (Quarto quarto : hotel.getListadeQuartos()) {
                System.out.println(quarto);
            }
        } else {
            System.out.println("Nenhum quarto cadastrado.");
        }

        System.out.println("\n[SERVIÇOS ADICIONAIS]");
        if (hotel.getListadeServicos() != null && !hotel.getListadeServicos().isEmpty()) {
            for (ServicoAdicional servico : hotel.getListadeServicos()) {
                System.out.println(servico);
            }
        } else {
            System.out.println("Nenhum serviço cadastrado.");
        }

        System.out.println("\n[RESERVAS]");
        if (hotel.getListadeReservas() != null && !hotel.getListadeReservas().isEmpty()) {
            for (Reserva reserva : hotel.getListadeReservas()) {
                System.out.println(reserva);
            }
        } else {
            System.out.println("Nenhuma reserva cadastrada.");
        }

        System.out.println("\n[HOSPEDAGENS ATIVAS]");
        if (hotel.getListadeHospedagens() != null && !hotel.getListadeHospedagens().isEmpty()) {
            for (Hospedagem hospedagem : hotel.getListadeHospedagens()) {
                System.out.println(hospedagem);
            }
        } else {
            System.out.println("Nenhuma hospedagem ativa.");
        }

        System.out.println("\n [RESERVA MAIS DISTANTE]");
        hotel.reservaMaisDistante();

        System.out.println("\n [MÉDIA DE GASTOS]");
        hotel.mediaHospede();

        System.out.println("\n [HÓSPEDE DE MAIOR VALOR]");
        hotel.maiorHospede();

        System.out.println("\n [RANKING DE HÓSPEDES]");
        hotel.rankingHospedes();

        System.out.println("\n [FATURAMENTO]");
        hotel.faturamento();
    }


    private String lerTextoValido(String mensagem) {
        while (true) {
            System.out.print(mensagem);
            String texto = scanner.nextLine().trim();
            if (!texto.isEmpty()) {
                return texto;
            }
            System.out.println("Comando inválido! O campo não pode ficar em branco.");
        }
    }

    private int lerInteiroValido(String mensagem) {
        while (true) {
            System.out.print(mensagem);
            try {
                return Integer.parseInt(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Comando inválido! Por favor, digite um número inteiro.");
            }
        }
    }

    private double lerDoubleValido(String mensagem) {
        while (true) {
            System.out.print(mensagem);
            try {
                double valor = Double.parseDouble(scanner.nextLine().trim().replace(",", "."));
                if (valor >= 0) {
                    return valor;
                }
                System.out.println("Comando inválido! O valor deve ser positivo.");
            } catch (NumberFormatException e) {
                System.out.println("Comando inválido! Digite um valor numérico válido (ex: 125.00).");
            }
        }
    }

    private LocalDate lerDataValida(String mensagem) {
        while (true) {
            System.out.print(mensagem);
            try {
                return LocalDate.parse(scanner.nextLine().trim(), FORMATO_DATA);
            } catch (DateTimeParseException e) {
                System.out.println("Comando inválido! Digite a data exatamente no formato dd/MM/yyyy.");
            }
        }
    }

    private String lerEnderecoPorCep() {
        while (true) {
            System.out.print("CEP para buscar endereço (só números ou com traço): ");
            String cep = scanner.nextLine().trim();
            try {
                System.out.println("Buscando endereço no ViaCEP...");
                ServicoViaCep.Endereco end = ServicoViaCep.buscarEndereco(cep);
                
                if (end != null && end.getLogradouro() != null && !end.getLogradouro().isEmpty()) {
                    String endereco = end.toString();
                    System.out.println("Endereço encontrado: " + endereco);
                    return endereco;
                } else {
                    System.out.println("Comando inválido! CEP não encontrado no ViaCEP. Tente novamente.");
                }
            } catch (Exception e) {
                System.out.println("Comando inválido! Erro ao consultar o CEP. Tente novamente.");
            }
        }
    }

    private Hospede lerHospedeExistente() {
        while (true) {
            System.out.print("CPF do Hóspede: ");
            String cpf = scanner.nextLine().trim();
            try {
                return buscarHospede(cpf);
            } catch (IllegalArgumentException e) {
                System.out.println("Comando inválido! " + e.getMessage() + " Tente novamente.");
            }
        }
    }

    private Quarto lerQuartoExistente() {
        while (true) {
            System.out.print("Número do Quarto: ");
            String numQuarto = scanner.nextLine().trim();
            try {
                return buscarQuarto(numQuarto);
            } catch (IllegalArgumentException e) {
                System.out.println("Comando inválido! " + e.getMessage() + " Tente novamente.");
            }
        }
    }

    private Reserva lerReservaExistente() {
        while (true) {
            System.out.print("CPF do Hóspede da Reserva: ");
            String cpf = scanner.nextLine().trim();
            try {
                return buscarReservaPorCpf(cpf);
            } catch (IllegalArgumentException e) {
                System.out.println("Comando inválido! " + e.getMessage() + " Tente novamente.");
            }
        }
    }

    private Hospedagem lerHospedagemExistente() {
        while (true) {
            System.out.print("ID da Hospedagem: ");
            String id = scanner.nextLine().trim();
            try {
                return buscarHospedagemPorId(id);
            } catch (IllegalArgumentException e) {
                System.out.println("Comando inválido! " + e.getMessage() + " Tente novamente.");
            }
        }
    }


    private Hospede buscarHospede(String cpf) {
    String cpfLimpo = cpf.replaceAll("\\D", "");
    for (Hospede hospede : hotel.getListadeHospedes()) {
        if (hospede.getCpf().replaceAll("\\D", "").equals(cpfLimpo)) {
            return hospede;
        }
    }
    throw new IllegalArgumentException("Hóspede não encontrado com o CPF informado.");
}

private Quarto buscarQuarto(String numero) {
    for (Quarto quarto : hotel.getListadeQuartos()) {
        if (quarto.getNumero().equals(numero)) {
            return quarto; 
        }
    }
    throw new IllegalArgumentException("Quarto não encontrado com o número informado.");
}

private Reserva buscarReservaPorCpf(String cpf) {
    String cpfLimpo = cpf.replaceAll("\\D", "");
    for (Reserva reserva : hotel.getListadeReservas()) {
        if (reserva.getHospede().getCpf().replaceAll("\\D", "").equals(cpfLimpo)) {
            return reserva;
        }
    }
    throw new IllegalArgumentException("Nenhuma reserva encontrada para este CPF.");
}

private Hospedagem buscarHospedagemPorId(String id) {
    for (Hospedagem h : hotel.getListadeHospedagens()) {
        if (h.getId().equalsIgnoreCase(id)) {
            return h; // Achou a hospedagem!
        }
    }
    throw new IllegalArgumentException("Hospedagem não encontrada com o ID informado.");
}

    private void editarHospedagem() {
    if (hotel.getListadeHospedagens().isEmpty()) {
        System.out.println("Hotel não possui hospedagens cadastradas.");
        return;
    }

    Hospedagem hospedagem = lerHospedagemExistente();
    Hospede hospede = hospedagem.getHospede();

    int op = -1;
    while (op != 0) {
        System.out.println("\n--- EDITAR HOSPEDAGEM (ID: " + hospedagem.getId() + ") ---");
        System.out.println("1 -> Dados do Hóspede");
        System.out.println("2 -> Data de Check-In");
        System.out.println("3 -> Data de Check-Out");
        System.out.println("0 -> Voltar ao Menu Principal");

        op = lerInteiroValido("Escolha uma opção: ");

        switch (op) {
            case 1 -> {
                int subOp = -1;
                while (subOp != 0) {
                    System.out.println("\n-- EDITAR DADOS DO HÓSPEDE: " + hospede.getNome().toUpperCase() + " --");
                    System.out.println("1 -> Nome (Atual: " + hospede.getNome() + ")");
                    System.out.println("2 -> CPF (Atual: " + hospede.getCpf() + ")");
                    System.out.println("3 -> Telefone (Atual: " + hospede.getTelefone() + ")");
                    System.out.println("4 -> E-mail (Atual: " + hospede.getEmail() + ")");
                    System.out.println("5 -> Endereço (Atual: " + hospede.getEndereco() + ")");
                    System.out.println("0 -> Voltar");

                    subOp = lerInteiroValido("Escolha uma opção: ");

                    switch (subOp) {
                        case 1 -> {
                            String novo = lerTextoValido("Digite o novo nome: ");
                            hospede.setNome(novo);
                            System.out.println("Nome atualizado com sucesso!");
                        }
                        case 2 -> {
                            String novo = lerTextoValido("Digite o novo CPF: ");
                            hospede.setCpf(novo);
                            System.out.println("CPF atualizado com sucesso!");
                        }
                        case 3 -> {
                            String novo = lerTextoValido("Digite o novo telefone: ");
                            hospede.setTelefone(novo);
                            System.out.println("Telefone atualizado com sucesso!");
                        }
                        case 4 -> {
                            String novo = lerTextoValido("Digite o novo e-mail: ");
                            hospede.setEmail(novo);
                            System.out.println("E-mail atualizado com sucesso!");
                        }
                        case 5 -> {
                            String novo = lerEnderecoPorCep();
                            hospede.setEndereco(novo);
                            System.out.println("Endereço atualizado com sucesso!");
                        }
                        case 0 -> System.out.println("Retornando ao menu da hospedagem...");
                        default -> System.out.println("Comando inválido!");
                    }
                }
            }
            case 2 -> {
                LocalDate novaData = lerDataValida("Digite a nova data de Check-In (dd/MM/yyyy): ");
                hospedagem.setDataCheckIN(novaData);
                System.out.println("Data de Check-In atualizada com sucesso!");
            }
            case 3 -> {
                LocalDate novaData = lerDataValida("Digite a nova data de Check-Out (dd/MM/yyyy): ");
                hospedagem.setDataCheckOUT(novaData);
                System.out.println("Data de Check-Out atualizada com sucesso!");
            }
            case 0 -> System.out.println("Retornando ao Menu Principal...");
            default -> System.out.println("Comando inválido!");
        }
    }
}
    private void cancelarReserva(){
        System.out.println("\n--- CANCELAR RESERVA ---");
        if (hotel.getListadeReservas().isEmpty()) {
            System.out.println("Hotel não possui reservas cadastradas.");
            return;
        } else {
            Reserva reserva = lerReservaExistente();
            hotel.getListadeReservas().remove(reserva);
            System.out.println("Reserva de "+reserva.getHospede().getNome()+" cancelada e removida.");
        }
    }

    private void checkOut(){
        System.out.println("\n--- CHECKOUT ---");
        if (hotel.getListadeHospedagens().isEmpty()) {
            System.out.println("Hotel não possui hospedagens cadastradas.");
            return;
        } else {
            Hospedagem hospedagem = lerHospedagemExistente();
            System.out.println("--- RESUMO DA CONTA ---");
            System.out.println("Hóspede: "+hospedagem.getHospede().getNome());
            System.out.println("Quarto: "+hospedagem.getQuarto().getNumero());
            System.out.println("Valor total a pagar: R$"+ String.format("%.2f", hospedagem.getValorTotal()));
            System.out.println("");

            int confima = lerInteiroValido("Confirmar pagamento e encerramento? (1 - Sim / 2 - Não)");

            if (confima == 1) {
                hospedagem.getQuarto().setDisponivel(true);
                hotel.getListadeHospedagens().remove(hospedagem);
                System.out.println("Checkout realizado.");
            } else {
                System.out.println("Operação cancelada");
            }

        }
    }
}