package com.hotel;

public class Main {
    public static void main(String[] args) {
        Hotel hotel = PersistenciaJson.carregar();
        if (hotel == null) {
            hotel = new Hotel("Benjamin's");
        }

        Menu menu = new Menu(hotel);
        menu.iniciar();
    }
}