package com.hotel;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

public class Reserva {
    private static final DateTimeFormatter FORMATO = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    private Hospede hospede;
    private Quarto quarto;
    private LocalDate dataReserva;
    private LocalDate dataEntradaPrevista;
    private LocalDate dataSaidaPrevista;

    public Reserva(Hospede hospede, Quarto quarto, String dataEntrada, String dataSaida) {
        setHospede(hospede);
        setQuarto(quarto);
        this.dataReserva = LocalDate.now();
        this.dataEntradaPrevista = converterData(dataEntrada);
        this.dataSaidaPrevista = converterData(dataSaida);
        validarDatas();
    }

    private LocalDate converterData(String dataTexto) {
        if (dataTexto == null || dataTexto.isBlank()) {
            throw new IllegalArgumentException("A data não pode estar em branco.");
        }
        try {
            return LocalDate.parse(dataTexto.trim(), FORMATO);
        } catch (Exception e) {
            throw new IllegalArgumentException("Data inválida. Use o formato dd/MM/aaaa (ex: 20/11/2026).");
        }
    }

    private void validarDatas() {
        if (dataEntradaPrevista.isBefore(dataReserva)) {
            throw new IllegalArgumentException("A data de entrada não pode ser anterior ao dia de hoje.");
        }
        if (!dataSaidaPrevista.isAfter(dataEntradaPrevista)) {
            throw new IllegalArgumentException("A data de saída deve ser pelo menos um dia após a entrada.");
        }
    }

    public double calcularDescontoAntecedencia() {
        long diasAntecedencia = ChronoUnit.DAYS.between(dataReserva, dataEntradaPrevista);
        if (diasAntecedencia >= 60) {
            return 0.70;
        }else if (diasAntecedencia >= 30){
            return 0.85;
        }else if (diasAntecedencia >= 15){
            return 0.95; 
        }else{
            return 1.00;
        }
    }

    public Hospede getHospede() { return hospede; }
    public void setHospede(Hospede hospede) {
        if (hospede == null) throw new IllegalArgumentException("O hóspede é obrigatório.");
        this.hospede = hospede;
    }

    public Quarto getQuarto() { return quarto; }
    public void setQuarto(Quarto quarto) {
        if (quarto == null) throw new IllegalArgumentException("O quarto é obrigatório.");
        this.quarto = quarto;
    }

    public LocalDate getDataCriacao() { return dataReserva; }
    public LocalDate getDataEntradaPrevista() { return dataEntradaPrevista; }
    public LocalDate getDataSaidaPrevista() { return dataSaidaPrevista; }

    @Override
    public String toString() {
        return "Reserva de " + hospede.getNome() + " | Quarto " + quarto.getNumero() +
               " | Entrada: " + dataEntradaPrevista.format(FORMATO) +
               " | Saída: " + dataSaidaPrevista.format(FORMATO) +
               " | Desconto: " + (int)(calcularDescontoAntecedencia() * 100) + "%";
    }
}