package com.hotel;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializer;

public class PersistenciaJson {
    private static final String ARQUIVO = "hotel.json";
    private static final DateTimeFormatter FORMATO = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    private static Gson criarGson() {
        return new GsonBuilder()
                .setPrettyPrinting()
                .registerTypeAdapter(LocalDate.class, (JsonSerializer<LocalDate>) (src, typeOfSrc, context) -> 
                    new JsonPrimitive(src.format(FORMATO)))
                .registerTypeAdapter(LocalDate.class, (JsonDeserializer<LocalDate>) (json, typeOfT, context) -> 
                    LocalDate.parse(json.getAsString(), FORMATO))
                .create();
    }

    public static void salvar(Hotel hotel) {
        Gson gson = criarGson();
        try (FileWriter writer = new FileWriter(ARQUIVO)) {
            gson.toJson(hotel, writer);
            System.out.println("Dados salvos com sucesso em " + ARQUIVO);
        } catch (IOException e) {
            System.err.println("Erro ao salvar os dados: " + e.getMessage());
        }
    }

    public static Hotel carregar() {
        Gson gson = criarGson();
        try (FileReader reader = new FileReader(ARQUIVO)) {
            Hotel hotel = gson.fromJson(reader, Hotel.class);
            System.out.println("Dados carregados com sucesso de " + ARQUIVO);
            return hotel;
        } catch (IOException e) {
            System.out.println("Nenhum arquivo encontrado. Criando novo hotel.");
            return null;
        }
    }
}
