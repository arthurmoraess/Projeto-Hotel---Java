package com.hotel;

public class Quarto {
    private String numero, tipo;
    private double valorDiaria;
    private boolean disponivel;


    public Quarto(String numero, double valorDiaria, boolean disponivel) {
        setNumero(numero);
        setValorDiaria(valorDiaria); 
        this.disponivel = disponivel;
    }

    private String formatarNumero(String numero){
        if (numero == null || numero.isBlank()) {
            throw new IllegalArgumentException("O número do quarto é obrigatório.");
        }
        try {
            int num = Integer.parseInt(numero.trim());
            if (num < 100) {
                return String.valueOf(100 + num);
            }
            return String.valueOf(num);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("O número do quarto deve conter apenas dígitos numéricos.");
        }
    }
    
    private String determinarTipo(double valor) {
        if (valor >= 125.0 && valor < 250) {
            return "Essencial";
        } else if (valor >= 250.0 && valor <= 500) {
            return "Confort";
        } else if (valor > 500.0) {
            return "Deluxe";
        } else {
            throw new IllegalArgumentException("Valor de diária inválido.");
        }
    }
    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = formatarNumero(numero);
    }

    public String getTipo() {
        return tipo;
    }

    public double getValorDiaria() {
        return valorDiaria;
    }

    public void setValorDiaria(double valorDiaria) {
        this.tipo = determinarTipo(valorDiaria);
        this.valorDiaria = valorDiaria;
    }

    public boolean isDisponivel() {
        return disponivel;
    }

    public void setDisponivel(boolean disponivel) {
        this.disponivel = disponivel;
    }

    @Override
    public String toString() {
        return "Quarto " + numero + " [" + tipo + "] - Diária: R$ " + valorDiaria + " | Disponível: " + (disponivel ? "Sim" : "Não");
    }
}

    


