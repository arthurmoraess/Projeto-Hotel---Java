package com.hotel;

public class ServicoAdicional {
    private String descricao;
    private double valor;

    public ServicoAdicional(String descricao, double valor) {
        setDescricao(descricao);
        setValor(valor);
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        if (descricao == null || descricao.isBlank()) {
            throw new IllegalArgumentException("A descrição do serviço é obrigatória.");
        }
        this.descricao = descricao.trim();
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        if (valor <= 0) {
            throw new IllegalArgumentException("O valor do serviço deve ser maior que zero.");
        }
        this.valor = valor;
    }

    @Override
    public String toString() {
        return "Serviço: " + descricao + " | Valor: R$ " + String.format("%.2f", valor);
    }
}