package com.hotel;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;

public class Hotel {
    private String nome;
    private ArrayList<Hospede> listadeHospedes = new ArrayList<>();
    private ArrayList<Quarto> listadeQuartos = new ArrayList<>();
    private ArrayList<ServicoAdicional> listadeServicos = new ArrayList<>();
    private ArrayList<Reserva> listadeReservas = new ArrayList<>();
    private ArrayList<Hospedagem> listadeHospedagens = new ArrayList<>();

    public void faturamento(){
        double faturamento = 0;
        for (Hospedagem hospedagem : listadeHospedagens) {
            faturamento += hospedagem.getValorTotal();
        }
        System.out.println("Faturamento total: R$"+faturamento);
    }

    public void mediaHospede(){
        if(listadeHospedagens.size() >= 1){
                double media, faturamento = 0;
            for (Hospedagem hospedagem : listadeHospedagens) {
                faturamento += hospedagem.getValorTotal();
            }
            media = faturamento/listadeHospedagens.size();
            System.out.println("Média de gasto por hóspede: R$"+media);
        }else{
            System.out.println("Hotel não possui hospedagens cadastradas.");
            return;
        }
        
    }

    public void maiorHospede(){
        if (listadeHospedagens.size() >= 1) {
                Hospedagem maior = listadeHospedagens.get(0);
                for (Hospedagem hospedagem : listadeHospedagens) {
                if(maior.getValorTotal() < hospedagem.getValorTotal()){
                    maior = hospedagem;
                }
            }
            System.out.println("Hóspede de maior valor: "+maior.getHospede().getNome()+" com o gasto de: R$"+maior.getValorTotal());
        } else {
            System.out.println("Hotel não possui hospedagens cadastradas.");
            return;
        }
        
    }

    public void rankingHospedes() {
    if (listadeHospedagens.isEmpty()) {
        System.out.println("Hotel não possui hospedagens cadastradas.");
        return;
    }else{
        ArrayList<Hospedagem> copiaHospedagens = new ArrayList<>(listadeHospedagens);

        System.out.println("\n========== RANKING DE HÓSPEDEDES ==========");
        int posicao = 1;

        while (!copiaHospedagens.isEmpty()) {
            Hospedagem maior = copiaHospedagens.get(0);
            for (Hospedagem h : copiaHospedagens) {
                if (h.getValorTotal() > maior.getValorTotal()) {
                    maior = h; // Atualiza a maior hospedagem encontrada
                }
            }
            System.out.println(posicao + "º Lugar: " + maior.getHospede().getNome() +
                            " | Quarto: " + maior.getQuarto().getNumero() +
                            " | Total: R$ " + maior.getValorTotal());

            posicao++;

            copiaHospedagens.remove(maior);
        }
    }
    
    }
    
    public void listarHospedagens(){
        if (listadeHospedagens.size() >= 1) {
            for (Hospedagem hospedagem : listadeHospedagens) {
                System.out.println();
                System.out.println("Id: "+hospedagem.getId());
                System.out.println("Hóspede: "+hospedagem.getHospede().getNome());
                System.out.println("Quarto: "+hospedagem.getQuarto().getNumero());
                System.out.println("CheckIn: "+hospedagem.getDataCheckIN());
                System.out.println("CheckOut: "+hospedagem.getDataCheckOUT());
                System.out.println("Valor total: R$"+hospedagem.getValorTotal());
                System.out.println();
            }
        } else {
            System.out.println("Hotel não possui hospedagens cadastradas.");
            return;
        }
    }
    private LocalDate converterParaData(String dataStr) {
    if (dataStr == null || dataStr.isBlank()) return null;
    try {
        if (dataStr.contains("-")) {
            return LocalDate.parse(dataStr); // Formato ISO (yyyy-MM-dd)
        }
        return LocalDate.parse(dataStr, java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy"));
    } catch (Exception e) {
        return null;
    }
    }

    public void reservaMaisDistante() {
        if (listadeReservas.isEmpty()) {
            System.out.println("Não há reservas cadastradas.");
            return;
        }

        Reserva distante = listadeReservas.get(0);

        for (Reserva reserva : listadeReservas) {
            // Comparação direta entre dois objetos LocalDate:
            if (reserva.getDataEntradaPrevista().isAfter(distante.getDataEntradaPrevista())) {
                distante = reserva;
            }
        }

        DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        System.out.println("\n--- RESERVA MAIS DISTANTE ---");
        System.out.println("Quarto: " + distante.getQuarto().getNumero());
        System.out.println("Hóspede: " + distante.getHospede().getNome() + " | Tel: " + distante.getHospede().getTelefone());
        System.out.println("Data Entrada: " + distante.getDataEntradaPrevista().format(formato));
        System.out.println("Data Saída: " + distante.getDataSaidaPrevista().format(formato));
    }

    public Hotel(String nome) {
        if (nome == null || nome.isBlank()) {
            throw new IllegalArgumentException("O nome do hotel é obrigatório.");
        }
        this.nome = nome.trim();
    }
    
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }

    public void cadastrarHospede(Hospede hospede){
        if (hospede == null) {
            throw new IllegalArgumentException("Hóspede Inválido");
        }else{
            listadeHospedes.add(hospede);
        }
    }

    public void cadastrarQuarto(Quarto quarto){
        if (quarto == null) {
            throw new IllegalArgumentException("Quarto Inválido");
        }else{
            listadeQuartos.add(quarto);
        }
    }

    public void cadastrarServicoAdicional(ServicoAdicional servico){
        if (servico == null) {
            throw new IllegalArgumentException("Serviço Inválido");
        }else{
            listadeServicos.add(servico);
        }
    }

    public void cadastrarReserva(Reserva reserva){
        if (reserva == null) {
            throw new IllegalArgumentException("Reserva Inválida");
        }else{
            listadeReservas.add(reserva);
        }
    }

    public void cadastrarHospedagem(Hospedagem hospedagem){
        if (hospedagem == null) {
            throw new IllegalArgumentException("Hóspedagem Inválida");
        }else{
            listadeHospedagens.add(hospedagem);
        }
    }

    public ArrayList<Hospede> getListadeHospedes() {
        return listadeHospedes;
    }

    public void setListadeHospedes(ArrayList<Hospede> listadeHospedes) {
        this.listadeHospedes = listadeHospedes;
    }

    public ArrayList<Quarto> getListadeQuartos() {
        return listadeQuartos;
    }

    public void setListadeQuartos(ArrayList<Quarto> listadeQuartos) {
        this.listadeQuartos = listadeQuartos;
    }

    public ArrayList<ServicoAdicional> getListadeServicos() {
        return listadeServicos;
    }

    public void setListadeServicos(ArrayList<ServicoAdicional> listadeServicos) {
        this.listadeServicos = listadeServicos;
    }

    public ArrayList<Reserva> getListadeReservas() {
        return listadeReservas;
    }

    public void setListadeReservas(ArrayList<Reserva> listadeReservas) {
        this.listadeReservas = listadeReservas;
    }

    public ArrayList<Hospedagem> getListadeHospedagens() {
        return listadeHospedagens;
    }

    public void setListadeHospedagens(ArrayList<Hospedagem> listadeHospedagens) {
        this.listadeHospedagens = listadeHospedagens;
    }

}
